package bgu.spl.net.srv;

import bgu.spl.net.api.bidi.Message;
import bgu.spl.net.api.bidi.MessageEncoderDecoder;
import bgu.spl.net.srv.messages.*;
import bgu.spl.net.srv.messages.Error;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

public class MessageEncoderDecoderImpl implements MessageEncoderDecoder<Message> {

    private byte[] buffer = new byte[1 << 10];
    private int len = 0;
    short opcode = 0;
    int zeroCounter = 0;
    int numOfUsers = 0;
    boolean follow = false;


    @Override
    public Message decodeNextByte(byte nextByte) {
        Message messageToReturn = null;
        pushByte(nextByte);


        if (len == 2) {
            opcode = bytesToShort(buffer);
        }
        if(opcode != 0){

            if(opcode == 1)
                messageToReturn = createRegisterAndLoginMessage(nextByte);
            else if(opcode == 2)
                messageToReturn = createRegisterAndLoginMessage(nextByte);
            else if (opcode == 3)
                messageToReturn = createLogoutMessage();
            else if (opcode == 4)
                messageToReturn = createFollowMessage(nextByte);
            else if (opcode == 5)
                messageToReturn = createPostMessage(nextByte);
            else if (opcode == 6)
                messageToReturn = createPMMessage(nextByte);
            else if (opcode == 7)
                messageToReturn = createUserListMessage();
            else if (opcode == 8)
                messageToReturn = createSTATMessage(nextByte);


        }
        return messageToReturn;
    }


    private Message createRegisterAndLoginMessage(byte nextByte){
        Message message = null;
        if(nextByte == '\0'){
            if(zeroCounter < 2)
                zeroCounter++;
        }
        if(zeroCounter == 2){
            int firstZeroIndex = findZeroIndex(2);
            //create user name and password strings
            String userName = new String(buffer, 2, firstZeroIndex - 2, StandardCharsets.UTF_8);
            String password = new String(buffer, firstZeroIndex +1, len - firstZeroIndex - 2, StandardCharsets.UTF_8);

            if(opcode == 1){ //register message
                zeroCounter = 0;
                message = new Register(userName, password);
                cleanData();

            }else{ //login message
                zeroCounter = 0;
                message = new Login(userName, password);
                cleanData();
            }
        }

        return message;
    }



    private Message createLogoutMessage(){
        cleanData();
        return new Logout();
    }

    private Message createFollowMessage(byte nextByte){
        Message message = null;
        List<String> userNameList = new LinkedList<>();

        if(len == 3){ //follow
            if(buffer[2] == '\0')
                follow = true;
        }
        else if(len == 5){ //num of users to follow/unfollow
            byte[] users = new byte[2];
            users[0] = buffer[3];
            users[1] = buffer[4];
            numOfUsers = bytesToShort(users);
        }

        if(len > 5) { //save all the names to follow/unfollow
            if(nextByte == '\0') //count number of users
                zeroCounter++;
            if(zeroCounter == numOfUsers){ //stop count the users
                int startIndex = 5;
                while (zeroCounter > 0) { //while there are still users to add to the list
                    int zeroIndex = findZeroIndex(startIndex);
                    String userName = new String(buffer, startIndex, zeroIndex - startIndex, StandardCharsets.UTF_8);
                    startIndex = zeroIndex + 1;
                    userNameList.add(userName);
                    zeroCounter--;
                }
                message = new Follow(follow, (short) numOfUsers, userNameList);
                follow = false;
                numOfUsers = 0;
                cleanData();
            }

        }

        return message;
    }

    private Message createPostMessage(byte nextByte){
        Message message = null;
        List<String> clientsToPost = new LinkedList<>();
        if(nextByte == '\0'){ //start the content
            String content = new String(buffer, 2, len - 3, StandardCharsets.UTF_8);
            for(int i =0; i<content.length(); i++){
                if(content.charAt(i) == '@'){ //find all users the are tagged in the post
                    String temp = content;
                    int nextSpace = findNextSpace(temp.substring(i));
                    String userName;
                    if(nextSpace != 0)
                        userName = temp.substring(i+1).substring(0, nextSpace-1);
                    else
                        userName = temp.substring(i+1);
                    clientsToPost.add(userName); //add to tagged users list
                }
            }
            message = new Post(content, clientsToPost);
            cleanData();
        }
        return message;
    }

    private Message createPMMessage(byte nextByte){
        Message message = null;
        if(nextByte == '\0'){
            if(zeroCounter < 2)
                zeroCounter++;
        }
        if(zeroCounter == 2){ //start the content
            int firstZeroIndex = findZeroIndex(2);
            String userName = new String (buffer, 2, firstZeroIndex - 2, StandardCharsets.UTF_8);
            String content = new String (buffer, firstZeroIndex + 1, len - firstZeroIndex - 2);
            message = new PM(userName, content);
            zeroCounter = 0;
            cleanData();
        }
        return message;
    }

    private Message createUserListMessage(){
        cleanData();
        return new UserList();
    }

    private Message createSTATMessage(byte nextByte){
        Message message = null;
        if ('\0' == nextByte){
            String userName = new String(buffer, 2, len - 3);
            message = new STAT(userName);
            cleanData();
        }
        return message;
    }

    //clean the data of all fields after creating a message
    private void cleanData(){
        buffer = new byte[1 << 10];
        opcode = 0;
        len = 0;
    }

    @Override
    public byte[] encode(Message message) {
        if(message instanceof Error | message instanceof ACKdefault){
            short Opcode = 0;
            short messageOpcode = 0;
            if(message instanceof Error){
                Opcode = ((Error) message).getOpcode();
                messageOpcode = ((Error) message).getMessageOpcode();
            }else{
                Opcode = ((ACKdefault) message).getOpcode();
                messageOpcode = ((ACKdefault) message).getMessageOpcode();
            }
            byte[] bytesToReturn = new byte[4];
            byte[] temp = shortToBytes(Opcode);
            bytesToReturn[0] = temp[0];
            bytesToReturn[1] = temp[1];
            byte[] temp1 = shortToBytes(messageOpcode);
            bytesToReturn[2] = temp1[0];
            bytesToReturn[3] = temp1[1];

            return bytesToReturn;
        }

        else if (message instanceof Notification){
            byte[] temp1 = ((Notification) message).getPostingUser().getBytes();
            byte[] temp2 = ((Notification) message).getContent().getBytes();
            int len = temp1.length + temp2.length + 5;
            byte[] bytesToReturn = new byte[len];
            short Opcode = ((Notification) message).getOpcode();
            byte[] temp = shortToBytes(Opcode);
            bytesToReturn[0] = temp[0];
            bytesToReturn[1] = temp[1];
            if(((Notification) message).getNotificationType() == '\0')
                bytesToReturn[2] = '\0';
            else
                bytesToReturn[2] = 1;

            for(int i =0; i<temp1.length; i++){
                bytesToReturn[i+3] = temp1[i];
            }
            bytesToReturn[temp1.length + 3] = (byte)'\0';

            for(int i =0; i<temp2.length; i++){
                bytesToReturn[i + temp1.length + 4] = temp2[i];
            }
            bytesToReturn[bytesToReturn.length-1] = (byte)'\0';

            return bytesToReturn;

        }

        else{
            if(message instanceof AckFollow | message instanceof  AckUserList){
                List<String> userNames = new LinkedList<>();
                for (String s:((ACK) message).getUserNameList()) {
                    userNames.add(s);
                }
                int listLengthInBytes = 0;
                byte[] temp = null;
                for(String s: userNames){
                    temp = s.getBytes();
                    listLengthInBytes = listLengthInBytes + temp.length + 1;
                }
                int len = listLengthInBytes + 6; //2 opcode, 2 opcodeFollow, 2 numOfUsers, users and zeros separate.
                byte[] bytesToReturn = new byte[len];

                byte[] temp1 = shortToBytes(((ACK) message).getOpcode());
                bytesToReturn[0]= temp1[0];
                bytesToReturn[1] = temp1[1];
                byte[] temp2 = shortToBytes(((ACK) message).getMessageOpcode());
                bytesToReturn[2]= temp2[0];
                bytesToReturn[3] = temp2[1];
                byte[] temp3 = shortToBytes(((ACK) message).getNumOfUsers());
                bytesToReturn[4]= temp3[0];
                bytesToReturn[5] = temp3[1];

                int count=6;
                for(String s: userNames){
                    temp = s.getBytes();
                    for (int j = 0; j < temp.length; j++) {
                        bytesToReturn[count+j] = temp[j];
                    }
                    count = count + temp.length;
                    bytesToReturn[count] = (byte)'\0';
                    count++;
                }

                return bytesToReturn;
            }

            else { // message instance of AckStat
                byte[] bytesToReturn = new byte[10];

                byte[] temp1 = shortToBytes(((AckStat) message).getOpcode());
                bytesToReturn[0]= temp1[0];
                bytesToReturn[1] = temp1[1];
                byte[] temp2 = shortToBytes(((AckStat) message).getMessageOpcode());
                bytesToReturn[2]= temp2[0];
                bytesToReturn[3] = temp2[1];
                byte[] temp3 = shortToBytes(((AckStat) message).getNumOfPosts());
                bytesToReturn[4]= temp3[0];
                bytesToReturn[5] = temp3[1];
                byte[] temp4 = shortToBytes(((AckStat) message).getNumOfFollowers());
                bytesToReturn[6]= temp4[0];
                bytesToReturn[7] = temp4[1];
                byte[] temp5 = shortToBytes(((AckStat) message).getNumOfFollowing());
                bytesToReturn[8]= temp5[0];
                bytesToReturn[9] = temp5[1];


                return bytesToReturn;
            }

        }

    }


    public short bytesToShort(byte[] byteArr)
    {
        short result = (short)((byteArr[0] & 0xff) << 8);
        result += (short)(byteArr[1] & 0xff);
        return result;
    }

    public byte[] shortToBytes(short num)
    {
        byte[] bytesArr = new byte[2];
        bytesArr[0] = (byte)((num >> 8) & 0xFF);
        bytesArr[1] = (byte)(num & 0xFF);
        return bytesArr;
    }

    private void pushByte(byte nextByte) {
        if (len >= buffer.length) {
            buffer = Arrays.copyOf(buffer, len * 2);
        }

        buffer[len++] = nextByte;
    }

    //find the index of the next zero in the string, starting from start index
    private int findZeroIndex(int startIndex){
        int zeroIndex = 2;
        boolean foundZero = false;
        for(int i=startIndex; i<buffer.length & !foundZero; i++){
            if(buffer[i] == '\0') {
                zeroIndex = i;
                foundZero = true;
            }
        }
        return zeroIndex;
    }

    //find the index of the next space in the string
    private int findNextSpace(String string){
        for(int i =0; i<string.length(); i++){
            if(string.charAt(i) == 32)
                return i;
        }
        return 0;
    }


}

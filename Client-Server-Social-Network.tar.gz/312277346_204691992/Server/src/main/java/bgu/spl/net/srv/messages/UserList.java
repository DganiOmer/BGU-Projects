package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class UserList implements Message {
    private short opcode;

    public UserList() {
        this.opcode = 7;
    }

    public short getOpcode() {
        return opcode;
    }
}

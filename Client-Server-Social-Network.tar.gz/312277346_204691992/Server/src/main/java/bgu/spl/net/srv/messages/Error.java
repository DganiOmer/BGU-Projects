package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class Error implements Message {
    private short opcode;
    private short messageOpcode;

    public Error (short messageOpcode){
        this.opcode = 11;
        this.messageOpcode = messageOpcode;
    }

    public short getOpcode() {
        return opcode;
    }

    public short getMessageOpcode() {
        return messageOpcode;
    }
}

package bgu.spl.net.impl.BGSServer;

import bgu.spl.net.srv.ResourceHolder;
import bgu.spl.net.srv.BidiMessagingProtocolImpl;
import bgu.spl.net.srv.MessageEncoderDecoderImpl;
import bgu.spl.net.srv.Server;


public class ReactorMain {

    public static void main(String[] args) {

        ResourceHolder resourceHolder = new ResourceHolder(); //one shared object

        Server.reactor(
                Integer.parseInt(args[0]), // port
                Integer.parseInt(args[1]), //number of threads
                ()-> new BidiMessagingProtocolImpl(resourceHolder), //protocol factory
                MessageEncoderDecoderImpl::new //encoderDecoder factory
        ).serve();
    }

}

package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

import java.util.LinkedList;
import java.util.List;

public class Follow implements Message {
    private short opcode;
    private boolean follow;
    private short NumOfUsers;
    private List<String> userNameList;

    public Follow (boolean follow, short NumOfUsers, List<String> userNameList){
        this.opcode = 4;
        this.follow = follow;
        this.NumOfUsers = NumOfUsers;
        this.userNameList = new LinkedList<>();
        for (String s: userNameList) {
            this.userNameList.add(s);
        }
    }

    public short getOpcode() {
        return opcode;
    }

    public boolean isFollow() {
        return follow;
    }

    public short getNumOfUsers() {
        return NumOfUsers;
    }

    public List<String> getUserNameList() {
        return userNameList;
    }
}

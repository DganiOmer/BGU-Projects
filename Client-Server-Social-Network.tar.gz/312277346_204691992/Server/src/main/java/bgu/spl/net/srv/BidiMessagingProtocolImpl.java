package bgu.spl.net.srv;

import bgu.spl.net.api.bidi.BidiMessagingProtocol;
import bgu.spl.net.api.bidi.Connections;
import bgu.spl.net.api.bidi.Message;
import bgu.spl.net.srv.messages.*;
import bgu.spl.net.srv.messages.Error;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

public class BidiMessagingProtocolImpl implements BidiMessagingProtocol<Message> {
    private boolean shouldTerminate;
    private Integer connectionId;
    private ConnectionsImpl<Message> connections;
    private ResourceHolder resourceHolder;

    public BidiMessagingProtocolImpl(ResourceHolder resourceHolder) {
        this.shouldTerminate = false;
        this.connectionId = 0;
        this.connections = null;
        this.resourceHolder = resourceHolder;
    }

    public void start(int connectionId, Connections connections) {
        this.connectionId = connectionId;
        this.connections = (ConnectionsImpl<Message>)connections;
    }


    public void process(Message message) {

        if (message instanceof Register) { //REGISTER
            if(connections.getActiveClients().containsKey(connectionId)) {
                synchronized (resourceHolder.getLock()) {
                    if (resourceHolder.getRegisteredClients().containsKey(((Register) message).getUserName())) { //IF ALREADY REGISTERED
                        sendError(1);
                    } else { //NEW REGISTER
                        Client client = new Client(((Register) message).getUserName(), ((Register) message).getPassword()); //NEW USER
                        resourceHolder.getRegisteredClients().put(((Register) message).getUserName(), client);
                        resourceHolder.getUsersRegistered().add(((Register) message).getUserName());
                        resourceHolder.getPostsMessages().put(client, new LinkedList<>());
                        connections.send(connectionId, new ACKdefault((short) 1));
                    }
                }
            }else{
                sendError(1);
            }

        }
        else if (message instanceof Login) { //LOGIN
            String userName = ((Login) message).getUserName();
            if(resourceHolder.getRegisteredClients().containsKey(userName)) { //if already register - error
                synchronized (resourceHolder.getRegisteredClients().get(userName)){
                    if (!resourceHolder.getLoggedInClients().containsKey(userName)) { // if already logged in
                        if(!alreadyLoggedIn(connectionId)) { //compare connection id
                            if (resourceHolder.getRegisteredClients().get(userName).getUserName().equals(((Login) message).getUserName())) {
                                if (resourceHolder.getRegisteredClients().get(userName).getPassword().equals(((Login) message).getPassword())) {
                                    Client client = resourceHolder.getRegisteredClients().get(userName); //new user
                                    client.setConnectionId(connectionId);
                                    resourceHolder.getLoggedInClients().put(userName, client);
                                    connections.send(connectionId, new ACKdefault((short) 2));
                                    while (!client.getNotificationQueue().isEmpty()) { //send the user all his pm and posts
                                        connections.send(connectionId, client.getNotificationQueue().poll());
                                    }
                                } else
                                    sendError(2);
                            }
                        } else
                            sendError(2);
                    } else
                        sendError(2);
                }
            } else
                sendError(2);
        }
        else if (message instanceof Logout) { //LOGOUT
            String userName = getUserName(connectionId);
            if(userName != null){
                Client user = resourceHolder.getRegisteredClients().get(userName);
                if(user != null){ //check the user already logged in
                    synchronized (user){
                        if(resourceHolder.getLoggedInClients().containsKey(userName)){
                            resourceHolder.getLoggedInClients().remove(userName); //logout the user
                            if(connections.send(connectionId, new ACKdefault((short) 3))){
                                this.shouldTerminate = true; //this protocol is done
                            }
                        }
                        else
                            sendError(3);
                    }
                }
                else
                    sendError(3);
            }
            else
                sendError(3);

        }
        else if (message instanceof Follow) { //FOLLOW
            String userName = getUserName(connectionId);
            boolean follow = ((Follow) message).isFollow();
            List<String> users = ((Follow) message).getUserNameList();
            List<String> usersToAddOrRemove = new LinkedList<>();
            if(userName != null){
                if (resourceHolder.getLoggedInClients().get(userName) != null) {
                    if (follow) {
                        for (String s : users) { //for all the users to follow
                            if (!s.equals(userName)) { //dont follow myself
                                if (resourceHolder.getRegisteredClients().get(userName).getFollowing().size() == 0) { //empty following list
                                    if (resourceHolder.getRegisteredClients().containsKey(s)) {
                                        addFollower(userName, s, usersToAddOrRemove);
                                    }
                                } else { // following list is not empty
                                    if (!resourceHolder.getRegisteredClients().get(userName).getFollowing().contains(s)) { //if already follow - dont add
                                        if (resourceHolder.getRegisteredClients().containsKey(s)) {
                                            addFollower(userName, s, usersToAddOrRemove);
                                        }
                                    }
                                }
                            }
                        }
                    } else { //unfollow
                        for (String s : users) {
                            if (resourceHolder.getRegisteredClients().get(userName).getFollowing().size() != 0) { //if not follow - error
                                if (resourceHolder.getRegisteredClients().get(userName).getFollowing().contains(s)) {//check if already follow
                                    resourceHolder.getLoggedInClients().get(userName).getFollowing().remove(s);
                                    usersToAddOrRemove.add(s);
                                    String thisName = resourceHolder.getRegisteredClients().get(userName).getUserName();
                                    resourceHolder.getRegisteredClients().get(s).getFollowers().remove(thisName);
                                }
                            }
                        }
                    }
                    if (usersToAddOrRemove.size() > 0) { //add all the succeed follow/unfollow to the message
                        Message ACK = new AckFollow((short) usersToAddOrRemove.size(), usersToAddOrRemove);
                        connections.send(connectionId, ACK);
                    } else
                        sendError(4);

                } else
                    sendError(4);
            }
            else
                sendError(4);
        }
        else if (message instanceof Post) { //POST
            String userName = getUserName(connectionId);
            if (resourceHolder.getLoggedInClients().containsKey(userName)) {
                Client thisUser = resourceHolder.getLoggedInClients().get(userName);
                List<String> clientsToPost = ((Post) message).getClientsToPost(); //all the client that are tagged in the posts
                Integer clientToPostId = 0;
                if (!clientsToPost.isEmpty()) {
                    clientsToPost = checkList(clientsToPost); // create new list when each name exist once
                    for (String s: clientsToPost) {
                        clientToPostId = getUserId(s); //so we can send the notification to the client
                        if (resourceHolder.getRegisteredClients().get(s) != null) {
                            if (!thisUser.getFollowers().contains(s)) { //dont send twice, if the user already follow us
                                Notification notification = new Notification('1', thisUser.getUserName(), ((Post) message).getContent());
                                synchronized (resourceHolder.getRegisteredClients().get(s)) {
                                    if (resourceHolder.getLoggedInClients().containsKey(s)) {
                                        connections.send(clientToPostId, notification);
                                    } else //if the user to dent is not logged in - save the notification for later
                                        resourceHolder.getRegisteredClients().get(s).getNotificationQueue().add(notification);
                                }
                            }
                        }
                    }
                }

                for (String follower:thisUser.getFollowers()) { //sent the post to all followers
                    if (resourceHolder.getRegisteredClients().get(follower) != null) {
                        Notification notification = new Notification('1', thisUser.getUserName(), ((Post) message).getContent());
                        synchronized (resourceHolder.getRegisteredClients().get(follower)) {
                            if (resourceHolder.getLoggedInClients().containsKey(follower)) {
                                connections.send(getUserId(follower), notification);
                            } else { //if the user to dent is not logged in - save the notification for later
                                resourceHolder.getRegisteredClients().get(follower).getNotificationQueue().add(notification);
                            }
                        }
                    }
                }
                synchronized (resourceHolder.getPostsMessages().get(thisUser)) {
                    resourceHolder.getPostsMessages().get(thisUser).add(new Pair(message, ((Post) message).getContent())); //add the post to the data of the user
                }
                ACKdefault ACK = new ACKdefault((short)5);
                connections.send(connectionId, ACK);
            }
            else
                sendError(5);

        }
        else if (message instanceof PM) { //PM
            String userName = getUserName(connectionId);
            if(userName != null) {
                if (resourceHolder.getLoggedInClients().containsKey(userName)) {
                    Client thisUser = resourceHolder.getLoggedInClients().get(userName);
                    String userToSend = ((PM) message).getUserName();
                    int userToSendId = getUserId(userToSend);
                    if (resourceHolder.getRegisteredClients().get(userToSend) != null) {
                        Notification notification = new Notification('\0', thisUser.getUserName(), ((PM) message).getContent());
                        synchronized (resourceHolder.getRegisteredClients().get(userToSend)) {
                            if (resourceHolder.getLoggedInClients().containsKey(userToSend)) { //if the user is logged in
                                connections.send(userToSendId, notification);
                                ACKdefault ACK = new ACKdefault((short) 6);
                                connections.send(connectionId, ACK);
                            } else { // user is not logged in - add the notification to his queue
                                resourceHolder.getRegisteredClients().get(userToSend).getNotificationQueue().add(notification);
                                ACKdefault ACK = new ACKdefault((short) 6);
                                connections.send(connectionId, ACK);
                            }

                        }
                        synchronized (resourceHolder.getPostsMessages().get(thisUser)) {
                            resourceHolder.getPostsMessages().get(thisUser).add(new Pair(message, ((PM) message).getContent())); //add the post to the data of the user
                        }
                    } else
                        sendError(6);
                } else
                    sendError(6);
            }
        }
        else if (message instanceof UserList) { //USERLIST
            String userName = getUserName(connectionId);
            if(userName != null){
                if (resourceHolder.getLoggedInClients().containsKey(userName)) {
                    Message ACK = new AckUserList((short) resourceHolder.getUsersRegistered().size(), resourceHolder.getUsersRegistered());
                    connections.send(connectionId, ACK);
                }
                else
                    sendError(7);
            }else
                sendError(7);
        }
        else if (message instanceof STAT) { //STAT
            String userName = getUserName(connectionId);
            int postCounter = 0;
            if(userName != null) {
                if (resourceHolder.getLoggedInClients().get(userName) != null) {
                    if (resourceHolder.getRegisteredClients().containsKey((((STAT) message).getUserName()))) {
                        Client user = resourceHolder.getRegisteredClients().get((((STAT) message).getUserName()));
                        synchronized (resourceHolder.getPostsMessages().get(user)) {
                            for (Pair p : resourceHolder.getPostsMessages().get(user)) { //add the post to the list
                                if (p.getFirst() instanceof Post) {
                                    postCounter++;
                                }
                            }
                            Message ACK = new AckStat((short) postCounter, (short) user.getFollowers().size(), (short) user.getFollowing().size());
                            connections.send(connectionId, ACK);
                        }
                    } else
                        sendError(8);

                } else
                    sendError(8);
            } else
                sendError(8);
        }

    }


    public boolean shouldTerminate() {
        return this.shouldTerminate;
    }

    //create an error message
    public void sendError(int messageOpcode) {
        Message error =  new Error((short)messageOpcode);
        connections.send(connectionId, error);
    }

    // find the name of the user by its Id
    public String getUserName(Integer connectionId){
        String userName = null;
        Set<String> keySet = resourceHolder.getLoggedInClients().keySet();
        for (String temp : keySet) {
            if (resourceHolder.getLoggedInClients().get(temp).getConnectionId().equals(connectionId)){
                userName = temp;
                if(!resourceHolder.getRegisteredClients().containsKey(temp))
                    userName = null;
            }
        }
        return userName;
    }

    //finr the ID of the user by its name
    public Integer getUserId(String name){
        Integer connectionId = 0;
        if(resourceHolder.getRegisteredClients().get(name) != null){
            connectionId = resourceHolder.getRegisteredClients().get(name).getConnectionId();
        }
        return connectionId;
    }

    //check if the connectionId is already logged in to the system
    public synchronized boolean alreadyLoggedIn(Integer connectionId){
        boolean answer = false;
        Set<String> keySet = resourceHolder.getLoggedInClients().keySet();
        for (String temp : keySet) {
            if (resourceHolder.getRegisteredClients().get(temp).getConnectionId().equals(connectionId)){
                answer = true;
            }
        }
        return answer;
    }

    //create a list which each name exist once
    public LinkedList<String> checkList(List<String> clientsToPost) {
        LinkedList<String> output = new LinkedList<>();
        for (String s:clientsToPost) {
            if(!output.contains(s))
                output.add(s);
        }
        return output;

    }

    //add the follower to the list to send back
    public List<String> addFollower(String following, String follower, List<String> usersToAddOrRemove){
        resourceHolder.getLoggedInClients().get(following).getFollowing().add(follower);
        usersToAddOrRemove.add(follower);
        resourceHolder.getRegisteredClients().get(follower).getFollowers().add(following);
        return usersToAddOrRemove;
    }

}

package bgu.spl.net.srv;

import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class ActorThreadPool {

    private final Map<Object, Queue<Runnable>> acts;
    private final ReadWriteLock actsRWLock;
    private final Set<Object> playingNow;
    private final ExecutorService threads;

    public ActorThreadPool(int threads) {
        this.threads = Executors.newFixedThreadPool(threads);
        acts = new WeakHashMap<>();
        playingNow = ConcurrentHashMap.newKeySet();
        actsRWLock = new ReentrantReadWriteLock();
    }

    public void submit(Object act, Runnable r) {
        synchronized (act) {
            if (!playingNow.contains(act)) {
                playingNow.add(act);
                execute(r, act);
            } else {
                pendingRunnablesOf(act).add(r);
            }
        }
    }

    public void shutdown() {
        threads.shutdownNow();
    }

    private Queue<Runnable> pendingRunnablesOf(Object act) {

        actsRWLock.readLock().lock();
        Queue<Runnable> pendingRunnables = acts.get(act);
        actsRWLock.readLock().unlock();

        if (pendingRunnables == null) {
            actsRWLock.writeLock().lock();
            acts.put(act, pendingRunnables = new LinkedList<>());
            actsRWLock.writeLock().unlock();
        }
        return pendingRunnables;
    }

    private void execute(Runnable r, Object act) {
        threads.execute(() -> {
            try {
                r.run();
            } finally {
                complete(act);
            }
        });
    }

    private void complete(Object act) {
        synchronized (act) {
            Queue<Runnable> pending = pendingRunnablesOf(act);
            if (pending.isEmpty()) {
                playingNow.remove(act);
            } else {
                execute(pending.poll(), act);
            }
        }
    }

    public static class ReactorMain {

        public static void main(String[] args) {

            ResourceHolder resourceHolder = new ResourceHolder(); //one shared object

            Server.reactor(
                    Integer.parseInt("5"), //number of threads //args[0]
                    Integer.parseInt("7777"), // port //args[1]
                    ()-> new BidiMessagingProtocolImpl(resourceHolder), //protocol factory
                    () -> new MessageEncoderDecoderImpl()).serve();
        }

    }

    public static class TPCMain {

        public static void main(String[] args) {

            ResourceHolder resourceHolder = new ResourceHolder(); //one shared object

            Server server = Server.threadPerClient(
                    Integer.parseInt(args[0]), //port // args[0]
                    () -> new BidiMessagingProtocolImpl(resourceHolder), //protocol factory
                    () -> new MessageEncoderDecoderImpl()); //message encoder decoder factory);

            server.serve();
        }

    }
}

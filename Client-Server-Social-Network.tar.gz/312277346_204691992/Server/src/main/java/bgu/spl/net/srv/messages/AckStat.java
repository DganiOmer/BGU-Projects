package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class AckStat implements Message {
    private short opcode;
    private short messageOpcode;
    private short numOfPosts;
    private short numOfFollowers;
    private short numOfFollowing;

    public AckStat (short numOfPosts, short numOfFollowers, short numOfFollowing) {
        this.opcode = 10;
        this.messageOpcode = 8;
        this.numOfPosts = numOfPosts;
        this.numOfFollowers = numOfFollowers;
        this.numOfFollowing = numOfFollowing;
    }

    public short getOpcode() {
        return opcode;
    }

    public short getMessageOpcode() {
        return messageOpcode;
    }

    public short getNumOfPosts() {
        return numOfPosts;
    }

    public short getNumOfFollowers() {
        return numOfFollowers;
    }

    public short getNumOfFollowing() {
        return numOfFollowing;
    }
}

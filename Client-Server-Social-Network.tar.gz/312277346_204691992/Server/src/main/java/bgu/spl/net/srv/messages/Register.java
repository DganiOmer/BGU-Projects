package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class Register implements Message {

    private short opcode;
    private String userName;
    private String password;

    public Register( String userName, String password){
        this.opcode = 1;
        this.userName = userName;
        this.password = password;
    }

    public short getOpcode() {
        return opcode;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
}

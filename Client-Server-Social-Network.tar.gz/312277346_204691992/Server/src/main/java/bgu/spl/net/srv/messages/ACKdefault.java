package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class ACKdefault implements Message {
    private short opcode;
    private short messageOpcode;

    public ACKdefault(short messageOpcode) {
        this.opcode = 10;
        this.messageOpcode = messageOpcode;
    }

    public short getOpcode() {
        return opcode;
    }

    public short getMessageOpcode() {
        return messageOpcode;
    }
}

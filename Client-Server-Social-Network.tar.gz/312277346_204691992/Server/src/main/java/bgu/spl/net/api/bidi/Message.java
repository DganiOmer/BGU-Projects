package bgu.spl.net.api.bidi;

public interface Message {

}

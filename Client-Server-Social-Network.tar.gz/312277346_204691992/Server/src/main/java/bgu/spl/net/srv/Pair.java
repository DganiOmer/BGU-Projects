package bgu.spl.net.srv;

public class Pair<T, T1> {
    private T first;
    private String second;

    public Pair(T first, String second){
        this.first = first;
        this.second = second;
    }

    public T getFirst() {
        return first;
    }

    public String getSecond() {
        return second;
    }
}

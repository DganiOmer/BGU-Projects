package bgu.spl.net.srv.messages;

import java.util.List;

public class AckUserList extends ACK{

    public AckUserList (short NumOfUsers, List<String> userNameList) {
        super((short)7, NumOfUsers, userNameList);
    }

    public short getOpcode() {
        return super.getOpcode();
    }

    public short getNumOfUsers() {
        return super.getNumOfUsers();
    }

    public List<String> getUserNameList() {
        return super.getUserNameList();
    }
}

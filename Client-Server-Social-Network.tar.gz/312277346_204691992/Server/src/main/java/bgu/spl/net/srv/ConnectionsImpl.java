package bgu.spl.net.srv;

import bgu.spl.net.api.bidi.Connections;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;


public class ConnectionsImpl<T> implements Connections<T> {

    private ConcurrentHashMap <Integer, ConnectionHandler<T>> ActiveClients;

    public ConnectionsImpl(){
        this.ActiveClients = new ConcurrentHashMap<>();
    }

    public ConcurrentHashMap<Integer, ConnectionHandler<T>> getActiveClients() {
        return ActiveClients;
    }

    public boolean send(int connectionId, T msg){
        boolean hasSent = false;
        if (ActiveClients.get(connectionId) != null) {
            ActiveClients.get(connectionId).send(msg);
            hasSent = true;
        }
        return hasSent;
    }

    public void broadcast(T msg){
        Set<Integer> keys = ActiveClients.keySet();
        for (Integer key: keys) {
            if (ActiveClients.get(key) != null)
                ActiveClients.get(key).send(msg);
        }
    }

    public void disconnect(int connectionId){
        if (ActiveClients.containsKey(connectionId))
            ActiveClients.remove(connectionId);
    }

}
package bgu.spl.net.srv.messages;

import java.util.List;

public class AckFollow extends ACK{


    public AckFollow (short NumOfUsers, List<String> userNameList) {
        super((short)4,NumOfUsers, userNameList);
    }

    public short getOpcode() {
        return super.getOpcode();
    }

    public short getMessageOpcode() {
        return super.getMessageOpcode();
    }

    public short getNumOfUsers() {
        return super.getNumOfUsers();
    }

    public List<String> getUserNameList() {
        return super.getUserNameList();
    }
}

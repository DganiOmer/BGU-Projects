package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class STAT implements Message {
    private short opcode;
    private String userName;

    public STAT (String userName) {
        this.opcode = 8;
        this.userName = userName;
    }

    public short getOpcode() {
        return opcode;
    }

    public String getUserName() {
        return userName;
    }
}

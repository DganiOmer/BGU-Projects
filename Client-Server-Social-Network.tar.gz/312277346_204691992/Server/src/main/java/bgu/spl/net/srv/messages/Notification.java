package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class Notification implements Message {
    private short opcode;
    private char notificationType;
    private String postingUser;
    private String content;

    public Notification(char notificationType ,String postingUser, String content) {
        this.opcode = 9;
        this.notificationType = notificationType;
        this.postingUser = postingUser;
        this.content = content;
    }

    public short getOpcode() {
        return opcode;
    }

    public char getNotificationType() {
        return notificationType;
    }

    public String getPostingUser() {
        return postingUser;
    }

    public String getContent() {
        return content;
    }
}

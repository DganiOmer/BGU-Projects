package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class PM implements Message {
    private short opcode;
    private String userName;
    private String content;

    public PM (String userName, String content) {
        this.opcode = 6;
        this.userName = userName;
        this.content = content;
    }

    public short getOpcode() {
        return opcode;
    }

    public String getUserName() {
        return userName;
    }

    public String getContent() {
        return content;
    }
}

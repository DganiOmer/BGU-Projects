package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;
import java.util.LinkedList;
import java.util.List;

public abstract class ACK implements Message {
    private short opcode;
    private short messageOpcode;
    private short NumOfUsers;
    protected List<String> userNameList;

    public ACK (short messageOpcode, short NumOfUsers, List<String> userNameList) {
        this.opcode = 10;
        this.messageOpcode = messageOpcode;
        this.NumOfUsers = NumOfUsers;
        this.userNameList = new LinkedList<>();
        for (String s: userNameList) {
            this.userNameList.add(s);
        }
    }

    public short getOpcode() {
        return opcode;
    }

    public short getMessageOpcode() {
        return messageOpcode;
    }

    public short getNumOfUsers() {
        return NumOfUsers;
    }

    public List<String> getUserNameList() {
        return userNameList;
    }
}

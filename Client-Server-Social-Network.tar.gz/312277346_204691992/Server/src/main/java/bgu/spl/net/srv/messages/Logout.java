package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class Logout implements Message {
    private short opcode;

    public Logout(){
        this.opcode = 3;
    }

    public short getOpcode() {
        return opcode;
    }
}

package bgu.spl.net.srv;

import bgu.spl.net.api.bidi.Message;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

public class ResourceHolder {

    private ConcurrentHashMap<String, Client> registeredClients; // key:userName , value:Client
    private ConcurrentHashMap<String, Client> loggedInClients; // key:userName , value:Client
    private ConcurrentHashMap<Client, List<Pair<Message, String>>> postsMessages; // key:Client , value:list of posts & PM
    private List<String> usersRegistered;
    private Object lock;


    private static class ResourceHolderInstance {
        private static ResourceHolder instance = new ResourceHolder();
    }

    /**
     * Retrieves the single instance of this class.
     */
    public static ResourceHolder getInstance() {

        return ResourceHolderInstance.instance;
    }

    public ResourceHolder (){

        this.registeredClients = new ConcurrentHashMap<>();
        this.loggedInClients = new ConcurrentHashMap<>();
        this.postsMessages = new ConcurrentHashMap<>();
        this.usersRegistered = new LinkedList<>();
        this.lock = new Object();

    }

    public ConcurrentHashMap<String, Client> getRegisteredClients() {
        return registeredClients;
    }

    public ConcurrentHashMap<String, Client> getLoggedInClients() {
        return loggedInClients;
    }

    public ConcurrentHashMap<Client, List<Pair<Message, String>>> getPostsMessages() {
        return postsMessages;
    }

    public List<String> getUsersRegistered() {
        return usersRegistered;
    }

    public Object getLock(){
        return this.lock;
    }
}

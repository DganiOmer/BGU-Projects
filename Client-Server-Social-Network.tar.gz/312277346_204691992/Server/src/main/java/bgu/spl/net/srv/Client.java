package bgu.spl.net.srv;

import bgu.spl.net.srv.messages.Notification;

import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public class Client {

    private Integer connectionId;
    private String userName;
    private String password;
    private List<String> followers;
    private List<String> following;
    private Queue<Notification> notificationQueue;

    public Client(String userName, String password){
        this.connectionId = 0;
        this.userName = userName;
        this.password = password;
        this.followers = new LinkedList<>();
        this.following = new LinkedList<>();
        this.notificationQueue = new ConcurrentLinkedQueue<>();

    }

    public Integer getConnectionId() {
        return connectionId;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }

    public List<String> getFollowers() {
        return followers;
    }

    public List<String> getFollowing() {
        return following;
    }

    public Queue<Notification> getNotificationQueue() {
        return notificationQueue;
    }

    public void setConnectionId(int connectionId){
        this.connectionId = connectionId;
    }
}

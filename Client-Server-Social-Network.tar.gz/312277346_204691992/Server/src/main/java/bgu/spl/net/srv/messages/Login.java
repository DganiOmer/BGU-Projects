package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

public class Login implements Message {
    private short opcode;
    private String userName;
    private String password;

    public Login (String userName, String password){
        this.opcode = 2;
        this.userName = userName;
        this.password = password;
    }

    public short getOpcode() {
        return opcode;
    }

    public String getUserName() {
        return userName;
    }

    public String getPassword() {
        return password;
    }
}

package bgu.spl.net.srv.messages;

import bgu.spl.net.api.bidi.Message;

import java.util.LinkedList;
import java.util.List;

public class Post implements Message {
    private short opcode;
    private String content;
    private List<String> clientsToPost;


    public Post (String content, List<String> clientsToPost) {
        this.opcode = 5;
        this.content = content;
        this.clientsToPost = new LinkedList<>();
        for (String s:clientsToPost) {
            this.clientsToPost.add(s);
        }
    }

    public short getOpcode() {
        return opcode;
    }

    public String getContent() {
        return content;
    }

    public List<String> getClientsToPost() {
        return clientsToPost;
    }
}

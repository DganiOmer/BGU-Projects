//
// Created by naamaron@wincs.cs.bgu.ac.il on 12/30/18.
//

#include <iostream>
#include <boost/thread.hpp>
#include <thread>
#include "../include/connectionHandler.h"

using namespace std;

class TaskRead {
private:
    ConnectionHandler &ch;
public:
    TaskRead (ConnectionHandler &ch) : ch(ch) {}

    void run(){
        while(!ch.isLoggedOut()){

            char opcodeBytes1[2];
            ch.getBytes(opcodeBytes1, 2);
            short opcode = ch.bytesToShort(opcodeBytes1);  //convert bytes to opcode short

            char messageOpcodeBytes[2];
            short messageOpcode;

            string line;

            if(opcode == 9) {
                char notificationType[1];
                ch.getBytes(notificationType, 1);
                string pmPost;
                if(notificationType[0] == '\0')
                    pmPost = "PM";
                else
                    pmPost = "POST";
                string userName;
                ch.getLine(userName); //convert bytes to userName string
                userName = userName.substr(0, userName.size()-1);
                string content;
                ch.getLine(content); //convert bytes to content string
                content = content.substr(0, content.size()-1);


                cout << "NOTIFICATION " << pmPost << " " << userName << " " << content << endl;
            }

            if(opcode == 10){
                ch.getBytes(messageOpcodeBytes, 2);
                messageOpcode = ch.bytesToShort(messageOpcodeBytes);

                if((messageOpcode == 1) | (messageOpcode == 2) | (messageOpcode == 5) | (messageOpcode == 6)){ //Default ACK
                    cout << "ACK " << messageOpcode << endl;
                }

                if(messageOpcode == 2){ //set the flag that a user is logged-in
                    ch.setLoggedIn();
                }

                if(messageOpcode == 8){ // STAT ACK
                    char numOfPosts[2];
                    ch.getBytes(numOfPosts, 2);
                    short numPosts = ch.bytesToShort(numOfPosts); //convert bytes to number of post short
                    char numOfFollowers[2];
                    ch.getBytes(numOfFollowers, 2);
                    short numFollowers = ch.bytesToShort(numOfFollowers); //convert bytes to number of followers
                    char numOfFollowing[2];
                    ch.getBytes(numOfFollowing, 2);
                    short numFollowing = ch.bytesToShort(numOfFollowing); //convert bytes to number of following
                    cout << "ACK " << messageOpcode << " " << numPosts << " " << numFollowers << " " << numFollowing << endl;
                }

                if(messageOpcode == 3){ // LOGOUT ACK
                    cout << "ACK " << messageOpcode << endl;
                    ch.setLoggedOut(); //success logout
                }

                if((messageOpcode == 4) | (messageOpcode == 7)){ // FOLLOW and USERLIST ACK
                    char numOfUsers[2];
                    ch.getBytes(numOfUsers, 2);
                    short numOfUsers1 = ch.bytesToShort(numOfUsers); //convert bytes to number of users in the userlist
                    string userList;
                    for(int i =0; i < numOfUsers1; i++){ //convert bytes to one string that include all users
                        line = "";
                        ch.getLine(line);
                        line = line.substr(0, line.size()-1);
                        userList = userList + line + " ";
                    }
                    cout << "ACK " << messageOpcode << " " << numOfUsers1 << " " << userList << endl;

                }
            }

            if(opcode == 11){ //ERROR
                char temp[2];
                ch.getBytes(temp, 2);
                messageOpcode = ch.bytesToShort(temp);
                cout << "ERROR " << messageOpcode << endl;
            }

        }


    }
};

class TaskWrite {
private:
    ConnectionHandler &ch;

public:
    TaskWrite (ConnectionHandler &ch) : ch(ch) {}

    void run(){
        while (!ch.isLoggedOut()) { //while client isn't logout
            const short bufsize = 1024;
            char buf[bufsize];
            cin.getline(buf, bufsize);
            string line(buf);
            int len = line.length();
            vector<string> inputStrings; //vector of strings that keeps the information after separate one string from line
            char opcodeBytes[2];
            while (len > 0) { //while the line string isn't empty
                int index = findNextSpaceIndex(line);
                if(index != 0) {
                    inputStrings.push_back(line.substr(0, index));//separate line string and add to vector
                    line = line.substr(index + 1);
                    len = line.length();
                } else {
                    inputStrings.push_back(line);
                    len = 0;
                }
                if (inputStrings[0]=="POST") {
                    inputStrings.push_back(line);
                    len= 0;
                }
                else if (inputStrings[0]=="PM") {
                    index = findNextSpaceIndex(line);
                    inputStrings.push_back(line.substr(0, index));
                    line = line.substr(index + 1);
                    len = line.length();
                    inputStrings.push_back(line);
                    len = 0;
                }
            }
            if(inputStrings[0] == "REGISTER"){
                ch.shortsToBytes(1, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                string username = inputStrings[1];
                ch.sendLine(username); //send username to buffer
                string password = inputStrings[2];
                ch.sendLine(password); //send password to buffer
            }
            else if(inputStrings[0] == "LOGIN"){
                ch.shortsToBytes(2, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                string username = inputStrings[1];
                ch.sendLine(username); //send username to buffer
                string password = inputStrings[2];
                ch.sendLine(password); //send password to buffer
            }
            else if(inputStrings[0] == "LOGOUT"){
                ch.shortsToBytes(3, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                if(ch.isLoggedIn()) // if command is logout and user s logged-in -> break
                    break;
            }
            else if(inputStrings[0] == "FOLLOW"){
                ch.shortsToBytes(4, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                char followByte[1];
                if(inputStrings[1] == "0")
                    followByte[0] = '\0'; //encoding follow/unfollow byte
                else
                    followByte[0] = 1;
                ch.sendBytes(followByte, 1);

                char numOfUsers[2];
                int num = stoi(inputStrings[2]);
                ch.shortsToBytes(num, numOfUsers); //encoding numOfUsers
                ch.sendBytes(numOfUsers,2);
                for (int i = 3; i < (signed)inputStrings.size(); i++) {
                    ch.sendLine(inputStrings[i]); //encoding userList
                }
            }
            else if(inputStrings[0] == "POST"){
                ch.shortsToBytes(5, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                ch.sendLine(inputStrings[1]);
            }
            else if(inputStrings[0] == "PM"){
                ch.shortsToBytes(6, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                ch.sendLine(inputStrings[1]);
                ch.sendLine(inputStrings[2]);
            }
            else if(inputStrings[0] == "USERLIST"){
                ch.shortsToBytes(7, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer

            }
            else if(inputStrings[0] == "STAT"){
                ch.shortsToBytes(8, opcodeBytes); //encoding opcode
                ch.sendBytes(opcodeBytes,2); //send opcode bytes to buffer
                string username = inputStrings[1];
                ch.sendLine(username); //send username bytes to buffer
            }

        }


    }
    int findNextSpaceIndex(string line){ //find next space by delimeter ' '
        for (int i = 0; i < (signed) line.length(); i++) {
            if(line[i] == ' '){
                return i;
            }
        }
        return 0;

    }
};

int main(int argc, char *argv[]){
    if (argc < 3) {
        std::cerr << "Usage: " << argv[0] << " host port" << std::endl << std::endl;
        return -1;
    }
    std::string host = argv[1];
    short port = (atoi(argv[2]));

    ConnectionHandler connectionHandler(host, port);
    if (!connectionHandler.connect()) {
        std::cerr << "Cannot connect to " << host << ":" << port << std::endl;
        return 1;
    }

    TaskRead taskRead(ref(connectionHandler));
    TaskWrite taskWrite(ref(connectionHandler));

    thread thread1(&TaskRead::run, &taskRead);
    thread thread2(&TaskWrite::run, &taskWrite);
    thread1.join();
    thread2.join();

    return 0;
}


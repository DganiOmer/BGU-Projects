#ifndef TABLE_H_
#define TABLE_H_

#include <vector>
#include "Customer.h"
#include "Dish.h"
#include <string>
#include <iostream>

typedef std::pair<int, Dish> OrderPair;

class Table{
public:
    virtual ~Table();
    Table();
    Table(int t_capacity);
    Table(Table &other);
    Table &operator=(Table &other);
    Table(Table &&other);
    Table &operator=(Table &&other);
    int getCapacity() const;
    void addCustomer(Customer* customer);
    void removeCustomer(int id);
    Customer* getCustomer(int id);
    std::vector<Customer*>& getCustomers();
    std::vector<OrderPair>& getOrders();
    std::vector<Customer*>& getNewCustomers();
    void order(const std::vector<Dish> &menu);
    std::vector<OrderPair> splitOrders(int id);
    void openTable();
    void closeTable();
    int getBill();
    int getTableId() const;
    bool isOpen();
    std::string getStatus();
    void addOrders(std::vector<OrderPair>);
    void setId(int id);
    void deleteCustomer();
    void copy(Table &other);
    std::vector<Customer *>& createCustomers(int id, std::vector<std::string> customers);
    Table* clone();
private:
    int capacity;
    bool open;
    std::vector<Customer*> customersList;
    std::vector<OrderPair> orderList; //A list of pairs for each order in a table - (customer_id, Dish)
    int tableId;
    std::vector<Customer*> newCustomers;
};


#endif
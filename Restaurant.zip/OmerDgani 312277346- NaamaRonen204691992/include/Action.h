#ifndef ACTION_H_
#define ACTION_H_

#include <string>
#include <iostream>
#include "Customer.h"


typedef std::pair<int, Dish> OrderPair;

enum ActionStatus{
    PENDING, COMPLETED, ERROR
};

//Forward declaration
class Restaurant;

class BaseAction{
public:
    virtual ~BaseAction();
    BaseAction();
    BaseAction(const BaseAction &other); //copy constructor
    ActionStatus getStatus() const;
    void setMsg(std::string msg);
    void setStatus(ActionStatus status);
    virtual void act(Restaurant& restaurant)=0;
    virtual std::string toString() const=0;
    virtual BaseAction* clone() = 0;
protected:
    void complete();
    void error(std::string errorMsg);
    std::string getErrorMsg() const;
private:
    std::string errorMsg;
    ActionStatus status;
};


class OpenTable : public BaseAction {
public:
    virtual ~OpenTable(); // DESTRUCTOR
    OpenTable(int id, std::vector<Customer *> &customersList);
    OpenTable(OpenTable &other); // OPEN TABLE COPY CONSTRUCTOR
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
    int getId();
    std::vector<Customer *>& getCustomers();
private:
	const int tableId;
	std::vector<Customer *> customers;
};


class Order : public BaseAction {
public:
    virtual ~Order();
    Order(int id);
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
    int getId();
private:
    const int tableId;
};


class MoveCustomer : public BaseAction {
public:
    virtual ~MoveCustomer();
    MoveCustomer(int src, int dst, int customerId);
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
private:
    const int srcTable;
    const int dstTable;
    const int id;
};


class Close : public BaseAction {
public:
    virtual ~Close();
    Close(int id);
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
	int getId();
private:
    const int tableId;
};


class CloseAll : public BaseAction {
public:
    virtual ~CloseAll();
    CloseAll();
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
private:
};


class PrintMenu : public BaseAction {
public:
    virtual ~PrintMenu();
    PrintMenu();
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
private:
};


class PrintTableStatus : public BaseAction {
public:
    virtual ~PrintTableStatus();
    PrintTableStatus(int id);
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
	int getId();
private:
    const int tableId;
};


class PrintActionsLog : public BaseAction {
public:
    virtual ~PrintActionsLog();
    PrintActionsLog();
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
private:
};


class BackupRestaurant : public BaseAction {
public:
    virtual ~BackupRestaurant();
    BackupRestaurant();
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
private:
};


class RestoreResturant : public BaseAction {
public:
    virtual ~RestoreResturant();
    RestoreResturant();
    void act(Restaurant &restaurant);
    std::string toString() const;
    BaseAction* clone();
};


#endif
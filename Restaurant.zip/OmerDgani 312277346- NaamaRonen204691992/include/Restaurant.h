#ifndef RESTAURANT_H_
#define RESTAURANT_H_

#include <vector>
#include <string>
#include "Dish.h"
#include "Table.h"
#include "Action.h"


class Restaurant{		
public:
    virtual ~Restaurant();
	Restaurant();
    Restaurant(const std::string &configFilePath);
    Restaurant(Restaurant &other);
    Restaurant &operator=(Restaurant &other);
    Restaurant(Restaurant &&other);
    Restaurant &operator=(Restaurant &&other);
    void start();
    int getNumOfTables() const;
    Table* getTable(int ind);
	const std::vector<BaseAction*>& getActionsLog() const; // Return a reference to the history of actions
	std::vector<BaseAction*>& NCgetActionsLog() ;
	std::vector<Dish>& getMenu();
    bool tableAvailable(int t_id);
	std::vector<Table*> getTables() const;
	void close();
	void deleteTables();
	void deleteActions();
	void copyTables(Restaurant &other);
	void copyActions(Restaurant &other);
	bool isOpen() const ;
    BaseAction* makeAction (std::string s);
    std::vector<Customer*> createCustomers(int id, std::vector<std::string> customersNames);

private:
    bool open;
    std::vector<Table*> tables;
    std::vector<Dish> menu;
    std::vector<BaseAction*> actionsLog;
    int customerId;
};

#endif


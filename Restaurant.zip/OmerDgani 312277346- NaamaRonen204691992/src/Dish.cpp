//
// Created by omerdga on 11/5/18.
//

#include "../include/Dish.h"
using namespace std;

Dish::Dish( int _id, string _name, int _price, DishType _type): id(_id), name(_name), price(_price), type(_type) {}

int Dish::getId() const {
    return id;
}

string Dish::getName() const {
    return name;
}

int Dish::getPrice() const {
    return price;
}

DishType Dish::getType() const {
    return type;
}

//
// Created by omerdga on 11/5/18.
//

#include "../include/Action.h"
#include "../include/Restaurant.h"
extern Restaurant* backup;

using namespace std;

BaseAction::~BaseAction() {} // DESTRUCTOR

BaseAction::BaseAction(): errorMsg(""), status(PENDING) {}

BaseAction::BaseAction(const BaseAction &other): errorMsg(other.getErrorMsg()), status(other.getStatus()) {} //copy constructor

ActionStatus BaseAction::getStatus() const {
    return status;
}

void BaseAction::setStatus(ActionStatus status) {
    this->status= status;
}

void BaseAction::complete() {
    this->status = COMPLETED;
}

void BaseAction::error(string errorMsg) {
    this->errorMsg = errorMsg;
    this->status = ERROR;
}

string BaseAction::getErrorMsg() const {
    return errorMsg;
}

void BaseAction::setMsg(string msg) {
    this->errorMsg= msg;
}

OpenTable::OpenTable(int tableId, vector<Customer *>& customersList): BaseAction(), tableId(tableId), customers(customersList){}

OpenTable:: ~OpenTable() {  // OPEN TABLE DESTRUCTOR
    for (int i =0; i < (int)customers.size(); i++){
        delete customers[i];  //delete from heap
        customers[i] = nullptr;
    }
    customers.clear();
}

OpenTable::OpenTable(OpenTable &other): BaseAction(other), tableId(other.getId()), customers{} { // OPEN TABLE COPY CONSTRUCTOR

    this->setMsg(other.getErrorMsg());
    this->setStatus(other.getStatus());
    for (int i =0; i < (int)other.getCustomers().size(); i++) {
        if (other.getCustomers()[i] != nullptr)
            this->customers.push_back(other.getCustomers()[i]->clone());
    }
}


void OpenTable::act(Restaurant &restaurant){

    if (restaurant.getNumOfTables() > tableId){
        if (!restaurant.getTable(tableId)->isOpen()) {
            if (restaurant.getTable(tableId)->getCapacity() >= (int)customers.size()){
                restaurant.getTable(tableId)->openTable();
                for (Customer* c: customers){
                    restaurant.getTable(tableId)->addCustomer(c->clone());
                }
                complete();
            }
            else {
                error("Table does not exist or is already open");
                cout << "Error: " + getErrorMsg() << endl;
            }

        }

        else {
            error("Table does not exist or is already open");
            cout << "Error: " + getErrorMsg() << endl;
        }
    }

    else {
        error("Table does not exist or is already open");
        cout << "Error: " + getErrorMsg() << endl;
    }
}


string OpenTable:: toString() const {
    string str = "open " + to_string(tableId);
    for (int i =0; i < (int)customers.size(); i++)
        str = str + " " + customers[i]->toString();
    if ( this->getStatus() == COMPLETED)
        str = str + " Completed";
    else
        str = str + " Error: " + getErrorMsg();
    return  str;
}

int OpenTable::getId(){
    return tableId;
}


vector<Customer *> &OpenTable::getCustomers(){
    return const_cast<vector<Customer *> &>(customers);
}

BaseAction* OpenTable::clone() {
    return new OpenTable(*this);
}

Order::Order(int id): BaseAction(), tableId(id){}

Order:: ~Order() {} // DESTRUCTOR

void Order::act(Restaurant &restaurant) {

    if(restaurant.tableAvailable(tableId)) {
        restaurant.getTable(tableId)->order(restaurant.getMenu());
        complete();
    }
    else {
        error("Table does not exist or is not open");
        cout << "Error: " + getErrorMsg() << endl;
    }
}

string Order::toString() const {
    string str;
    str = "order " + to_string(tableId);
    if ( getStatus() == COMPLETED)
        str = str + " Completed";
    else
        str = str + " Error: " + getErrorMsg();
    return str;

}

int Order::getId(){
    return tableId;
}

BaseAction* Order::clone() {
    return new Order(*this);
}


MoveCustomer::MoveCustomer(int src, int dst, int customerId) : BaseAction(), srcTable(src), dstTable(dst), id(customerId) {}

MoveCustomer:: ~MoveCustomer() {} // DESTRUCTOR

void MoveCustomer::act(Restaurant &restaurant) {

    if (restaurant.tableAvailable(dstTable) and restaurant.tableAvailable(srcTable)){
        if ((int)restaurant.getTable(dstTable)->getCapacity() > (int)restaurant.getTable(dstTable)->getCustomers().size()){
            if (restaurant.getTable(srcTable)->getCustomer(id) != nullptr){
                  restaurant.getTable(dstTable)->addCustomer(restaurant.getTable(srcTable)->getCustomer(id)->clone()); //duplicate the customer to dst table
                  restaurant.getTable(dstTable)->addOrders(restaurant.getTable(srcTable)->splitOrders(id)); // add customer orders to dst table and remove his orders from src table
                  restaurant.getTable(srcTable)->removeCustomer(id); // remove customer and his orders from src table
                  complete();
            }
            else{
                error("Cannot move customer");
            cout << "Error: " + getErrorMsg() << endl;
            }
        }

        else{
            error("Cannot move customer");
            cout << "Error: " + getErrorMsg() << endl;
        }
    }
    else{
        error("Cannot move customer");
        cout << "Error: " + getErrorMsg() << endl;
    }

    if(restaurant.getTable(srcTable)->getCustomers().size() == 0)
        restaurant.getTable(srcTable)->closeTable();


}

string MoveCustomer::toString() const {
    string str;
    str = "move " + to_string(srcTable) + " " + to_string(dstTable) + " " +  to_string(id);
    if ( getStatus() == COMPLETED)
        str = str + " Completed";
    else
        str = str + " Error: " + getErrorMsg();
    return str;
}

BaseAction* MoveCustomer::clone() {
    return new MoveCustomer(*this);
}


Close::Close(int id): BaseAction(), tableId(id){}

Close:: ~Close() {} // DESTRUCTOR

void Close::act(Restaurant &restaurant){

    if (restaurant.tableAvailable(tableId)){
        cout << "Table " + to_string(tableId) << " was closed. Bill " << to_string(restaurant.getTable(tableId)->getBill()) << "NIS" << endl;
        restaurant.getTable(tableId)->closeTable();
        complete();
    }

    else {
        error("Table does not exist or is not open");
        cout << "Error: " + getErrorMsg() << endl;
    }
}

string Close::toString() const {
    string str;
    str = "close " + to_string(tableId);
    if ( getStatus() == COMPLETED)
        str = str + " Completed";
    else if (getStatus() == ERROR)
        str = str + " Error: " + getErrorMsg();

    return str;
}

int Close::getId() {
    return tableId;
}

BaseAction* Close::clone() {
    return new Close(*this);
}


CloseAll::CloseAll(): BaseAction() {}

CloseAll:: ~CloseAll() {} // DESTRUCTOR


void CloseAll::act(Restaurant &restaurant){

    for(int i =0; i < (int)restaurant.getTables().size(); i++){
        if(restaurant.getTable(i)->isOpen()){
            cout << "Table " << to_string(restaurant.getTables()[i]->getTableId()) <<  " was closed. Bill " << to_string(restaurant.getTables()[i]->getBill()) << "NIS" << endl;
            restaurant.getTable(i)->closeTable();
        }
    }
    restaurant.close();
    complete();
}
string CloseAll::toString() const {
    string str = "close all";
    if ( getStatus() == COMPLETED)
        str = str + " Completed";

    return str;
}

BaseAction* CloseAll::clone() {
    return new CloseAll(*this);
}


PrintMenu::PrintMenu(): BaseAction() {}

PrintMenu:: ~PrintMenu() {} // DESTRUCTOR

void PrintMenu::act(Restaurant &restaurant) {

    for (Dish d: restaurant.getMenu()) {
        string type;
        if (d.getType() == BVG)
            type = "BVG";
        if (d.getType() == VEG)
            type = "VEG";
        if (d.getType() == ALC)
            type = "ALC";
        if (d.getType() == SPC)
            type = "SPC";
        cout << d.getName() << " " << type << " " << to_string(d.getPrice()) << "NIS" << endl;
    }
    complete();
}

string PrintMenu::toString() const {
    string str = "menu ";
    if ( getStatus() == COMPLETED)
        str = str + "Completed";

    return str;
}

BaseAction* PrintMenu::clone() {
    return new PrintMenu(*this);
}


PrintTableStatus::PrintTableStatus(int id): BaseAction(), tableId(id) {}

PrintTableStatus:: ~PrintTableStatus() {} // DESTRUCTOR

void PrintTableStatus::act(Restaurant &restaurant) {

    cout << "Table " << to_string(tableId) << " status: " << restaurant.getTable(tableId)->getStatus() << endl;
    if (restaurant.getTable(tableId)->isOpen()) {
        cout << "Customers:"<< endl;
        for(int i =0; i < (int)restaurant.getTable(tableId)->getCustomers().size(); i++){
            cout << to_string(restaurant.getTable(tableId)->getCustomers()[i]->getId()) << " " << restaurant.getTable(tableId)->getCustomers()[i]->getName() << endl;
        }

        cout << "Orders:"<< endl;
        for(int i =0; i < (int)restaurant.getTable(tableId)->getOrders().size(); i++){
            cout << restaurant.getTable(tableId)->getOrders()[i].second.getName() << " "
            << to_string(restaurant.getTable(tableId)->getOrders()[i].second.getPrice()) << "NIS "
            << to_string(restaurant.getTable(tableId)->getOrders()[i].first) << endl;
        }

        cout << "Current Bill: " << to_string(restaurant.getTable(tableId)->getBill()) << "NIS" << endl;
        complete();
    }

    complete();
}

int PrintTableStatus::getId(){
    return tableId;
}

string PrintTableStatus::toString() const{
    string str;
    str = "status " + to_string(tableId);
    if ( getStatus() == COMPLETED)
        str = str + " Completed";

    return str;
}

BaseAction* PrintTableStatus::clone() {
    return new PrintTableStatus(*this);
}


PrintActionsLog::PrintActionsLog(): BaseAction() {}

PrintActionsLog:: ~PrintActionsLog() {} // DESTRUCTOR

void PrintActionsLog::act(Restaurant &restaurant) {

    for (int i=0; i < (int)restaurant.NCgetActionsLog().size(); i++){

        cout << restaurant.NCgetActionsLog()[i]->toString() << endl;

    }
    complete();
}


string PrintActionsLog:: toString() const{
    string str = "log ";
    if ( getStatus() == COMPLETED)
        str = str + "Completed";
    return str;
}

BaseAction* PrintActionsLog::clone() {
    return new PrintActionsLog(*this);

}



BackupRestaurant::BackupRestaurant() : BaseAction(){}

BackupRestaurant:: ~BackupRestaurant() {} // DESTRUCTOR

void BackupRestaurant::act(Restaurant &restaurant){

    if (backup == nullptr)
        backup = new Restaurant(restaurant);
    else {
        delete backup;
        backup = new Restaurant(restaurant);
    }
    complete();

}

string BackupRestaurant::toString() const{
    string str = "backup ";
    if ( getStatus() == COMPLETED)
        str = str + "Completed";

    return str;

}

BaseAction* BackupRestaurant::clone() {
    return new BackupRestaurant(*this);

}




RestoreResturant:: RestoreResturant() : BaseAction() {}

RestoreResturant:: ~RestoreResturant() {} // DESTRUCTOR

void RestoreResturant::act(Restaurant &restaurant){

    if (backup == nullptr){
        error("Error: No backup available");
        cout << getErrorMsg() << endl;
    }

    else {
        restaurant = *backup;
        complete();
    }

}

string RestoreResturant::toString() const {
    string str = "restore ";
    if ( getStatus() == COMPLETED)
        str = str + "Completed";
    else
        str = str + getErrorMsg();
    return str;
}

BaseAction* RestoreResturant::clone() {
    return new RestoreResturant(*this);
}


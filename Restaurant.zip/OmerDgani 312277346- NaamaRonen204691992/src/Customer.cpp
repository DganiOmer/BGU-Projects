//
// Created by omerdga on 11/5/18.
//

#include "../include/Customer.h"
using namespace std;


Customer::Customer(string c_name, int c_id) : name(c_name), id(c_id) {}

string Customer::getName() const {
    return name;
}

int Customer::getId() const {
    return id;
}

Customer:: ~Customer()=default;

VegetarianCustomer::VegetarianCustomer(std::string name, int id) : Customer(name, id), orders{}{}



VegetarianCustomer:: ~VegetarianCustomer()=default; // DESTRUCTOR

vector<int> VegetarianCustomer:: order(const vector<Dish> &menu) {
    vector<int> orders;

    if (smallestID(VEG, menu) != -1){
         if (expensBev(VEG, menu) != -1){
             orders.push_back(smallestID(VEG, menu));
             orders.push_back(expensBev(BVG, menu));
         }
    }
    return orders;

}

int VegetarianCustomer::smallestID(DishType d_type, const vector<Dish> &menu) {
    int id = INT_MAX;
    for( Dish d: menu) {
        if(d.getType() == d_type) {
            if (d.getId() < id)
                id = d.getId();
        }
    }
    if (id != INT_MAX)
        return id;
    return -1;
}

int VegetarianCustomer::expensBev(DishType d_type, const std::vector<Dish> &menu) {
    int id = -1;
    int price = -1;
    for( Dish d: menu) {
        if(d.getType() == d_type) {
            if (d.getPrice() > price){
                price = d.getPrice();
                id = d.getId();
            }
            if (d.getPrice() == price) {
                if (id > d.getId()) {
                    id = d.getId();
                }
            }
        }
    }
    if (price != -1)
        return id;
    return -1;
}

string VegetarianCustomer::toString() const{
    return this->getName() + ",veg";
}

Customer* VegetarianCustomer::clone() const {
    Customer* c= new VegetarianCustomer(*this);
    return c;
}


CheapCustomer::CheapCustomer(std::string name, int id) : Customer(name, id), ordered(), orders{}{}


CheapCustomer:: ~CheapCustomer()=default; // DESTRUCTOR

vector<int> CheapCustomer::order(const std::vector<Dish> &menu){
    vector<int> orders;


    if (!ordered & (cheapDish(menu) != -1)){
        orders.push_back(cheapDish(menu));
        ordered = true;
    }
    return orders;

}

int CheapCustomer::cheapDish(const std::vector<Dish> &menu) {
    int id = -1;
    int price = INT_MAX;
    for( Dish d: menu) {
        if (d.getPrice() < price){
            price = d.getPrice();
            id = d.getId();
        }
        if (d.getPrice() == price) {
            if (id > d.getId()) {
                id = d.getId();
            }
        }
    }
    if (price != INT_MAX)
        return id;
    return -1;
}


string CheapCustomer::toString() const {
    return this->getName() + ",chp";
}

Customer* CheapCustomer::clone() const {
    Customer* c = new CheapCustomer(*this);
    return c;
}



SpicyCustomer::SpicyCustomer(std::string name, int id) : Customer(name, id), ordered(), orders{} {}


SpicyCustomer:: ~SpicyCustomer()=default; // DESTRUCTOR

vector<int> SpicyCustomer::order(const std::vector<Dish> &menu){
    vector<int> orders;
    if (!ordered & (expenSpy(SPC, menu) != -1)) {
        orders.push_back(expenSpy(SPC, menu));
        ordered = true;
    }
    else if (ordered & (cheapNA(menu) != -1)){
        orders.push_back(cheapNA(menu));
    }
    return orders;
}

int SpicyCustomer::expenSpy(DishType d_type, const std::vector<Dish> &menu) {
    int id = -1;
    int price = -1;
    for( Dish d: menu) {
        if(d.getType() == d_type) {
            if (d.getPrice() > price){
                price = d.getPrice();
                id = d.getId();
            }
        }
    }
    if (price != -1)
        return id;
    return -1;
}

int SpicyCustomer::cheapNA(const std::vector<Dish> &menu) {
    int id = -1;
    int price = INT_MAX;
    for( Dish d: menu) {
        if(d.getType() == BVG) {
            if (d.getPrice() < price) {
                price = d.getPrice();
                id = d.getId();
            }
            if (d.getPrice() == price) {
                if (id > d.getId()) {
                    id = d.getId();
                }
            }
        }
    }

    if (price != INT_MAX)
        return id;
    return -1;
}


string SpicyCustomer::toString() const {
    return this->getName() + ",spc";
}

Customer* SpicyCustomer::clone() const {
    Customer* c = new SpicyCustomer(*this);
    return c;
}

AlchoholicCustomer::AlchoholicCustomer(std::string name, int id):Customer(name, id), ordered(), orders{}, alcDish{}{}

AlchoholicCustomer:: ~AlchoholicCustomer()=default; // DESTRUCTOR

vector<int> AlchoholicCustomer::order(const std::vector<Dish> &menu){
    vector<int> orders;

    if (!ordered) {
        int size = (int)menu.size();
        for(int i=0; i < size; i++){
            if(menu[i].getType()==ALC){
                alcDish.push_back(menu[i]);
            }
        }
        ordered=true;
    }

    if(alcDish.size() == 0) // no alcoholic dish in the menu
        return orders;


    int price = INT_MAX;
    int index = -1;
    int id= -1;

    for (int i=0; i < (int)alcDish.size(); i++){
        if (alcDish[i].getPrice() < price) {
            id = alcDish[i].getId();
            price = alcDish[i].getPrice();
            index = i;
        }
        if (alcDish[i].getPrice() == price) {
            if (id > alcDish[i].getId()) {
                id = alcDish[i].getId();
                index = i;
            }
        }
    }

    if (id != -1)
        orders.push_back(alcDish[index].getId());
    else
        return orders;

    vector<Dish> newAlc;
    for (int j = 0; j < (int)alcDish.size(); j++){
        if(index != j)
            newAlc.push_back(alcDish[j]);
    }


    alcDish.clear();
    for (int i=0; i< (int)newAlc.size(); i++){
        alcDish.push_back(newAlc[i]);
    }

    return orders;

}

string AlchoholicCustomer::toString() const {
    return this->getName() + ",alc";
}

Customer* AlchoholicCustomer::clone() const {
    Customer* c = new AlchoholicCustomer(*this);
    return c;
}
//
// Created by omerdga on 11/5/18.
//

#include "../include/Table.h"
using namespace std;

Table::~Table() {   //DESTRUCTOR
    deleteCustomer();
}

Table::Table() : capacity(0), open(false), customersList(), orderList(), tableId(), newCustomers{}{}

Table::Table(int t_capacity) : capacity(t_capacity), open(false), customersList{}, orderList(), tableId(),  newCustomers{}{}

Table::Table(Table &other): capacity(other.capacity), open(other.open), customersList{}, orderList{}, tableId(other.tableId), newCustomers{} { //COPY CONSTRUCTOR

    this->capacity = other.getCapacity();
    this->open = other.isOpen();
    for (int i =0; i < (int)other.getOrders().size(); i++)
        orderList.push_back(other.getOrders()[i]);

    this->tableId = other.getTableId();

    copy(other);
}

Table &Table::operator=(Table & other) {   //OPERATOR ASSIGNMENT CONSTRUCTOR
    if (this == &other)
        return *this;

    this->capacity = other.getCapacity();
    this->open = other.isOpen();

    this->orderList.clear();
    for (int i =0; i < (int)other.getOrders().size(); i++)
        orderList.push_back(other.getOrders()[i]);

    this->tableId = other.getTableId();

    for (int i =0; i < (int)other.getCustomers().size(); i++){
        customersList.push_back(other.getCustomers()[i]);  //steal the pointer
        other.getCustomers()[i] = nullptr;
    }

    for (int i =0; i < (int)other.getNewCustomers().size(); i++){
        newCustomers.push_back(other.getNewCustomers()[i]);  //steal the pointer
        other.getNewCustomers()[i] = nullptr;
    }

    return *this;
}

Table::Table(Table &&other): capacity(other.capacity), open(other.open), customersList{}, orderList{}, tableId(other.tableId), newCustomers{} { //MOVE CONSTRUCTOR


    for (int i =0; i < (int)other.getOrders().size(); i++)
        orderList.push_back(other.getOrders()[i]);

    this->tableId = other.getTableId();

    for (int i =0; i < (int)other.getCustomers().size(); i++)
        this->customersList.push_back(other.getCustomers()[i]);

    for (int i =0; i < (int)other.getCustomers().size(); i++)
        other.getCustomers()[i] = nullptr;
    other.getCustomers().clear();

    for (int i =0; i < (int)other.getNewCustomers().size(); i++)
        this->newCustomers.push_back(other.getNewCustomers()[i]);

    for (int i =0; i < (int)other.getNewCustomers().size(); i++)
        other.getNewCustomers()[i] = nullptr;
    other.getNewCustomers().clear();


}

Table &Table::operator=(Table &&other) {   //MOVE ASSIGNMENT CONSTRUCTOR
    if (this == &other)
        return *this;

    this->capacity = other.getCapacity();
    this->open = other.isOpen();
    this->tableId = other.getTableId();

    this->orderList.clear();

    for (int i = 0; i < (int)other.getOrders().size(); i++)
        orderList.push_back(other.getOrders()[i]);

    this->deleteCustomer();

    for (int i = 0; i < (int)other.getCustomers().size(); i++){
        this->customersList.push_back(other.getCustomers()[i]);
        other.getCustomers()[i] = nullptr;
    }
    other.getCustomers().clear();

    for (int i = 0; i < (int)other.getNewCustomers().size(); i++){
        this->newCustomers.push_back(other.getNewCustomers()[i]);
        other.getNewCustomers()[i] = nullptr;
    }
    other.getNewCustomers().clear();

    return *this;
}


int Table::getCapacity() const {
    return capacity;
}

int Table::getTableId() const {
    return tableId;
}

void Table::addCustomer(Customer *customer) {
    if ( (int)getCapacity() > (int)customersList.size() ) {
        customersList.push_back(customer);
    }
}

void Table::removeCustomer(int id) {
    bool found= false;

    for (int i=0; !found and i < (int)customersList.size(); i++){
        if((customersList[i])->getId() == id) {
            delete customersList[i];
            customersList[i] = nullptr;
            customersList.erase(customersList.begin() +i);
            found = true;
         }
    }
}

Customer* Table::getCustomer (int id) {
    bool found= false;

    for (int i=0; !found and i < (int)customersList.size(); i++){
        if( (customersList[i])->getId() == id) {
            found = true;
            return customersList[i];
        }

    }

    return nullptr;
}


vector<Customer*>& Table::getCustomers() {
    return customersList;
}

vector<OrderPair>& Table::getOrders() {
    return orderList;
}

vector<Customer*>& Table::getNewCustomers() {
    return newCustomers;
}

void Table::openTable() {
    this->open = true;
}

void Table::closeTable() {
    this->open = false;
//    this->tableId = -1;
    deleteCustomer();
    orderList.clear();
}

int Table::getBill() {
    int sum = 0;
    for( int i=0; i < (int)orderList.size(); i++) {
        sum = sum + orderList[i].second.getPrice();
    }
    return sum;
}

bool Table::isOpen() {
    return this->open;
}


void Table::order(const std::vector<Dish> &menu) {

    for (int i = 0; i < (int)customersList.size(); i++) {
        vector<int> customerOrders = customersList[i]->order(menu);
        for(int j = 0; j < (int)customerOrders.size(); j++){
            for (int k = 0; k < (int)menu.size(); k++){
                if(menu[k].getId() == customerOrders[j]){
                     pair<int, Dish> OrderPair(customersList[i]->getId(), menu[k]);
                     orderList.push_back(OrderPair);
                     cout << customersList[i]->getName() << " ordered " << OrderPair.second.getName() << endl;
                }
            }

        }
    }
}


vector<OrderPair> Table::splitOrders(int id) {
    vector<OrderPair> customerOrders;
    vector<OrderPair> tableOrders = orderList;
    orderList.clear();

    for (int j=0; j < (int)tableOrders.size(); j++) {

        if (tableOrders[j].first == id) {
            customerOrders.push_back(tableOrders[j]);
        }
        else {
            orderList.push_back(tableOrders[j]);
        }
    }

    return  customerOrders;

}

void Table::addOrders(vector<OrderPair> newOrders) {
    for (int i = 0; i < (int)newOrders.size(); i++){
        orderList.push_back(newOrders[i]);
    }

}

string Table::getStatus(){
    if(isOpen())
        return "open";
    return "closed";
}

void Table::setId(int id) {
    this->tableId = id;
}


void Table::copy(Table &other) {
    for (int i =0; i < (int)other.getCustomers().size(); i++) {
        if (other.getCustomers()[i] != nullptr)
            this->customersList.push_back(other.getCustomers()[i]->clone());
    }

    for (int i =0; i < (int)other.getNewCustomers().size(); i++) {
        if (other.getNewCustomers()[i] != nullptr)
            this->newCustomers.push_back(other.getNewCustomers()[i]->clone());
    }
}

void Table::deleteCustomer() {
    for (int i =0; i < (int)customersList.size(); i++){
        delete customersList[i];  //delete from heap
        customersList[i] = nullptr;
    }
    customersList.clear();

    for (int i =0; i < (int)newCustomers.size(); i++){
        delete newCustomers[i];  //delete from heap
        newCustomers[i] = nullptr;
    }
    newCustomers.clear();
}

vector<Customer*>& Table::createCustomers(int id, vector<string> customers) {

    newCustomers.clear();

    for (int i =0; i < (int)customers.size() ; i++) {
        string delimiter = ",";
        size_t splitIndex = customers[i].find(delimiter);
        if ((int)splitIndex != -1) {
            string name = customers[i].substr(0, splitIndex);
            string type = customers[i].substr(splitIndex + 1);
            if (type == "veg") {
                Customer *c = new VegetarianCustomer(name, id);
                id = id + 1;
                newCustomers.push_back(c);
            }
            else if (type == "spc") {
                Customer *c = new SpicyCustomer(name, id);
                id = id + 1;
                newCustomers.push_back(c);
            }
            else if (type == "chp") {
                Customer *c = new CheapCustomer(name, id);
                id = id + 1;
                newCustomers.push_back(c);
            }
            else if (type == "alc") {
                Customer *c = new AlchoholicCustomer(name, id);
                id = id + 1;
                newCustomers.push_back(c);
            }
        }
    }
    return newCustomers;
}

Table* Table::clone() {
    return new Table(*this);
}


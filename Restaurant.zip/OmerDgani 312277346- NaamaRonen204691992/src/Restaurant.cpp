//
// Created by omerdga on 11/5/18.
//


#include "../include/Restaurant.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
using namespace std;

Restaurant:: Restaurant() :  open(), tables{}, menu{}, actionsLog{}, customerId(-1) {}


Restaurant:: Restaurant(const std::string &configFilePath) :  open(), tables{}, menu{}, actionsLog{}, customerId(-1) {

    this->customerId = 0;

    string line ="";
    ifstream file;
    file.open(configFilePath);

    while (file.is_open()) {

        bool foundLine = false;
        while (foundLine == false && getline(file, line)) {
            if (!line.empty() && line != "\r" && line.front() != '#') {
                int tablesSize = stoi(line.c_str());
                tables.reserve(tablesSize);
                foundLine = true;
            }
        }


        int tableId = 0;
        bool foundLine1 = false;

        while (foundLine1 == false && getline(file, line)) {
            string tab;
            stringstream stream(line);
            if (!line.empty() && line != "\r" && line.front() != '#') {
                while (getline(stream, tab, ',')) {
                    Table *table = new Table(stoi(tab));
                    table->setId(tableId);
                    tables.push_back(table);
                    tableId = tableId + 1;
                }
                foundLine1 = true;
            }
        }

        int dishId = 0;

        while (getline(file, line)) {
            if (!line.empty() && line != "\r" && line.front() != '#') {
                string tab2, name, price;
                DishType dishType;
                stringstream stream(line);
                int indexLine = 1;
                while (getline(stream, tab2, ',')) {
                    if (indexLine == 1) {
                        name = tab2;
                    } else if (indexLine == 2) {
                        if (tab2 == "VEG")
                            dishType = VEG;
                        else if (tab2 == "SPC")
                            dishType = SPC;
                        else if (tab2 == "BVG")
                            dishType = BVG;
                        else if (tab2 == "ALC")
                            dishType = ALC;
                    } else if (indexLine == 3) {
                        price = tab2;
                    }

                    indexLine++;
                }

                menu.emplace_back(dishId, name, stoi(price), dishType);

                dishId++;

            }
        }

        file.close();
    }

}

Restaurant::~Restaurant() {    //DESTRUCTOR
    deleteTables();
    deleteActions();
}

Restaurant::Restaurant(Restaurant &other) :  open(), tables{}, menu{}, actionsLog{}, customerId(-1) { //COPY CONSTRUCTOR
    this->open = other.isOpen();

    for (int i =0; i < (int)other.getMenu().size(); i++)
        menu.push_back(other.getMenu()[i]);

    this->customerId = other.customerId;
    copyTables(other);
    copyActions(other);
}

Restaurant& Restaurant::operator=(Restaurant & other) {   //OPERATOR ASSIGNMENT CONSTRUCTOR
    if (this == &other)
        return *this;

    this->open = other.isOpen();

    this->menu.clear();

    for (int i =0; i < (int)other.getMenu().size(); i++)
        menu.push_back(other.getMenu()[i]);

    this->customerId = other.customerId;

    this->deleteTables();
    copyTables(other);

    this->deleteActions();
    copyActions(other);

    return *this;
}

Restaurant::Restaurant(Restaurant &&other): open(), tables{}, menu{}, actionsLog{}, customerId(-1) { //MOVE CONSTRUCTOR

    this->open = other.isOpen();

    for (int i =0; i < (int)other.getMenu().size(); i++)
        menu.push_back(other.getMenu()[i]);

    this->customerId = other.customerId;

    for (int i =0; i < (int)other.getTables().size(); i++)
        this->tables.push_back(other.getTables()[i]);

    for (int i =0; i < (int)other.getTables().size(); i++)
        other.getTables()[i] = nullptr;
    other.getTables().clear();


    for (int i =0; i < (int)other.NCgetActionsLog().size(); i++)
        this->actionsLog.push_back(other.NCgetActionsLog()[i]);

    for (int i =0; i < (int)other.getActionsLog().size(); i++)
        other.NCgetActionsLog()[i] = nullptr;
    other.NCgetActionsLog().clear();
}

Restaurant& Restaurant::operator=(Restaurant &&other) {   //MOVE ASSIGNMENT CONSTRUCTOR
    if (this == &other)
        return *this;

    this->open = other.isOpen();

    this->menu.clear();
    for (int i =0; i < (int)other.getMenu().size(); i++)
        menu.push_back(other.getMenu()[i]);

    this->customerId = other.customerId;


    this->deleteTables();

    for (int i = 0; i < (int)other.getTables().size(); i++)
        this->tables.push_back(other.getTables()[i]);

    for (int i = 0; i < (int)other.getTables().size(); i++)
        other.getTables()[i] = nullptr;
    other.getTables().clear();


    this->deleteActions();

    for (int i = 0; i < (int)other.NCgetActionsLog().size(); i++)
        this->actionsLog.push_back(other.NCgetActionsLog()[i]);

    for (int i = 0; i < (int)other.getActionsLog().size(); i++)
        other.NCgetActionsLog()[i] = nullptr;
    other.NCgetActionsLog().clear();

    return *this;
}

//This method opens the restaurant
void Restaurant:: start() {
     this->open = true;
     cout << "Restaurant is now open!" << endl;

     while (open){
         string action;
         getline(cin, action);
         BaseAction* A = makeAction(action);
         A->act(*this);
         actionsLog.push_back(A);
     }

}

void Restaurant:: close() {
    this->open = false;
}

bool Restaurant::isOpen() const {
    return open;
}

int Restaurant::getNumOfTables() const{
    return (int)tables.size();
}

Table* Restaurant::getTable(int ind) {
    return tables[ind];
}

const vector<BaseAction*>& Restaurant::getActionsLog() const {
    return this->actionsLog;
}

vector<BaseAction*>& Restaurant::NCgetActionsLog() {
    return this->actionsLog;
}

vector<Dish>& Restaurant::getMenu() {
    return menu;
}

std::vector<Table*> Restaurant::getTables() const{
    return this->tables;
}

bool Restaurant::tableAvailable(int t_id) {
    if ((int)tables.size() < t_id)
        return false;
    if (!getTable(t_id)->isOpen())
        return false;

    return true;

}

//This method delete all tables from the restaurant
void Restaurant::deleteTables() {
    for (int i =0; i < (int)tables.size(); i++){
        delete tables[i];  //delete from heap
        tables[i] = nullptr;
    }
    tables.clear();
}

//This method delete all actions log from the restaurant
void Restaurant::deleteActions() {
    for (int i =0; i < (int)actionsLog.size(); i++){
        delete actionsLog[i];  //delete from heap
        actionsLog[i] = nullptr;
    }
    actionsLog.clear();
}

//This method copy all tables from the restaurant
void Restaurant::copyTables(Restaurant &other) {
    for (int i =0; i < (int)other.getTables().size(); i++) {
        if (other.getTables()[i] != nullptr){
            this->tables.push_back(other.getTables()[i]->clone());
        }
    }
}

//This method copy all actions log from the restaurant
void Restaurant::copyActions(Restaurant &other) {
    for (int i =0; i < (int)other.getActionsLog().size(); i++) {
        if (other.getActionsLog()[i] != nullptr)
            this->actionsLog.push_back(other.getActionsLog()[i]->clone());
    }
}

//This method gets the command from the user and make it into an action
BaseAction* Restaurant:: makeAction (string s) {
    BaseAction* output;
    string::size_type st;
    istringstream tokenStream(s);
    string tab;
    vector<string> actions;

    while (getline(tokenStream, tab, ' ')) {

        actions.push_back(tab);
    }

    if ((actions[0]) == "open") {
        int id = stoi(actions[1], &st);
        actions.erase(actions.begin() + 1);
        actions.erase(actions.begin() + 0);
        vector<Customer*> customers = createCustomers(customerId, actions);

        output = new OpenTable(id, customers);



        customerId = customerId + (int)actions.size();  // gives the customer Id for each customer

        return output;

    }

    if ((actions[0]) == "order") {
        int id = stoi(actions[1], &st);

        output = new Order(id);

        return output;

    }

    if ((actions[0]) == "move") {
        int src = stoi(actions[1], &st);
        int dst = stoi(actions[2], &st);
        int id = stoi(actions[3], &st);

        output = new MoveCustomer(src, dst, id);

        return output;

    }

    if ((actions[0]) == "close") {
        int id = stoi(actions[1], &st);

        output = new Close(id);

        return output;

    }

    if ((actions[0]) == "closeall") {

        output = new CloseAll();

        return output;

    }

    if ((actions[0]) == "menu") {

        output = new PrintMenu();

        return output;

    }

    if ((actions[0]) == "status") {
        int id = stoi(actions[1], &st);

        output = new PrintTableStatus(id);

        return output;

    }

    if ((actions[0]) == "log") {

        output = new PrintActionsLog();

        return output;

    }

    if ((actions[0]) == "backup") {

        output = new BackupRestaurant();

        return output;

    }

    if ((actions[0]) == "restore") {

        output = new RestoreResturant();

        return output;

    }

    return nullptr;

}


vector<Customer*> Restaurant::createCustomers(int id, vector<string> customersNames) {

    vector<Customer*> customers;

    for (int i =0; i < (int)customersNames.size() ; i++) {
        string delimiter = ",";
        size_t splitIndex = customersNames[i].find(delimiter);
        if ((int)splitIndex != -1) {
            string name = customersNames[i].substr(0, splitIndex);
            string type = customersNames[i].substr(splitIndex + 1);
            if (type == "veg") {
                Customer *c = new VegetarianCustomer(name, id);
                id = id + 1;
                customers.push_back(c);
            }
            else if (type == "spc") {
                Customer *c = new SpicyCustomer(name, id);
                id = id + 1;
                customers.push_back(c);
            }
            else if (type == "chp") {
                Customer *c = new CheapCustomer(name, id);
                id = id + 1;
                customers.push_back(c);
            }
            else if (type == "alc") {
                Customer *c = new AlchoholicCustomer(name, id);
                id = id + 1;
                customers.push_back(c);
            }
        }
    }
    return customers;
}

# file create_db.py

import sqlite3
import os
import atexit
import sys

DBExist = os.path.isfile('schedule.db')

dbcon = sqlite3.connect('schedule.db')
with dbcon:
    cursor = dbcon.cursor()


def close_db():
    dbcon.commit()
    dbcon.close()


atexit.register(close_db)


def createtables():
        cursor.execute("""CREATE TABLE courses(id INTEGER PRIMARY KEY,
        course_name TEXT NOT NULL, student TEXT NOT NULL, number_of_students INTEGER NOT NULL,
        class_id INTEGER REFERENCES classrooms(id), course_length INTEGER NOT NULL)""")
        cursor.execute("""CREATE TABLE students(grade TEXT PRIMARY KEY, count INTEGER NOT NULL)""")
        cursor.execute("""CREATE TABLE classrooms(id INTEGER PRIMARY KEY, location TEXT NOT NULL,
        current_course_id INTEGER NOT NULL, current_course_time_left INTEGER NOT NULL)""")


def inserttables(configfile):
    with open(configfile) as inputfile:
        for line in inputfile:
            params = line.split(',')
            if params[0] == 'S':
                cursor.execute("INSERT INTO students VALUES(?,?)", (params[1].strip(), params[2].strip()))
            elif params[0] == 'R':
                cursor.execute("INSERT INTO classrooms VALUES(?,?,?,?)", (params[1].strip(), params[2].strip(),
                                                                          0, 0))
            elif params[0] == 'C':
                cursor.execute("INSERT INTO courses VALUES(?,?,?,?,?,?)",
                               (params[1].strip(), params[2].strip(), params[3].strip(), params[4].strip(),
                                params[5].strip(), params[6].strip()))


def printtables():
    print('courses')
    cursor.execute("SELECT * FROM courses")
    list = cursor.fetchall()
    for item in list:
        print(item)

    print('classrooms')
    cursor.execute("SELECT * FROM classrooms")
    list = cursor.fetchall()
    for item in list:
        print(item)

    print('students')
    cursor.execute("SELECT * FROM students")
    list = cursor.fetchall()
    for item in list:
        print(item)


def main(argv):
    if not DBExist:  # first time creating the database tables.
        createtables()
        inserttables(argv[1])
        printtables()


if __name__ == '__main__':
    main(sys.argv)

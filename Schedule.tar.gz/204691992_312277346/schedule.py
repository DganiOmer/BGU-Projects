# file schedule.py

import create_db
import sqlite3
import os
import atexit
import sys


def main():
    DBExist = os.path.isfile('schedule.db')

    dbcon = sqlite3.connect('schedule.db')
    with dbcon:
        cursor = dbcon.cursor()

    def close_db():
        dbcon.commit()
        dbcon.close()

    atexit.register(close_db)

    def assignclass(class_id1, course_id1):
        cursor.execute("SELECT * FROM courses WHERE id =?", [course_id1])
        course1 = cursor.fetchone()
        course_time = course1[5]
        cursor.execute("UPDATE classrooms SET current_course_id =? WHERE id=?", [course_id1, class_id1])
        cursor.execute("UPDATE classrooms SET current_course_time_left =? WHERE id=(?)", [course_time, class_id1])
        dbcon.commit()

    def checkandreducestudents(course_id1):
        cursor.execute("SELECT * FROM courses WHERE id =(?)", [course_id1])
        course3 = cursor.fetchone()
        student_name = course3[2]
        course_students = course3[3]
        cursor.execute("SELECT * FROM students WHERE grade =?", [student_name])
        student = cursor.fetchone()
        students_available = student[1]
        if students_available > course_students:
            update_students = students_available - course_students
            cursor.execute("UPDATE students SET count=? WHERE grade=?",
                           [update_students, student_name])
            dbcon.commit()
            return True
        else:
            return False

    def printtables():
        print('courses')
        cursor.execute("SELECT * FROM courses")
        list3 = cursor.fetchall()
        for item1 in list3:
            print(item1)

        print('classrooms')
        cursor.execute("SELECT * FROM classrooms")
        list4 = cursor.fetchall()
        for item2 in list4:
            print(item2)

        print('students')
        cursor.execute("SELECT * FROM students")
        list5 = cursor.fetchall()
        for item3 in list5:
            print(item3)

    iterationcounter = 0
    cursor.execute("SELECT * FROM courses")
    list1 = cursor.fetchall()
    number_of_courses = 0
    for item4 in list1:
        number_of_courses += 1

    if number_of_courses is 0:
        printtables()

    while DBExist and number_of_courses > 0:

        cursor.execute("SELECT * FROM classrooms")
        classes = cursor.fetchall()

        for item in classes:
            time_left = item[3]
            location = item[1]
            current_course_id = item[2]
            class_id = item[0]

            if time_left is 0:
                cursor.execute("SELECT * FROM courses WHERE courses.class_id =(?)", [class_id])
                course = cursor.fetchone()
                if course is not None:
                    if checkandreducestudents(course[0]):
                        assignclass(class_id, course[0])
                        course_name = course[1]
                        s = '(' + str(iterationcounter) + ') ' + location + ": " + course_name + " is schedule to start"
                        print(s)

            elif time_left is 1:
                cursor.execute("SELECT * FROM courses WHERE courses.class_id =(?)", [class_id])
                course_to_remove = cursor.fetchone()
                course_name1 = course_to_remove[1]
                s = '(' + str(iterationcounter) + ') ' + location + ": " + course_name1 + " is done"
                print(s)
                cursor.execute("DELETE FROM courses WHERE id=?", [current_course_id])
                dbcon.commit()
                cursor.execute("SELECT * FROM courses WHERE courses.class_id =(?)", [class_id])
                course = cursor.fetchone()
                if course is not None:
                    course_name2 = course[1]
                    course_time = course[5]
                    course_id = course[0]
                    if checkandreducestudents(course_id) is True:
                        cursor.execute("UPDATE classrooms SET current_course_time_left=? WHERE id=?",
                                       [course_time, class_id])
                        cursor.execute("UPDATE classrooms SET current_course_id =? WHERE id=?",
                                       [course_id, class_id])
                    s = '(' + str(iterationcounter) + ') ' + location + ": " + course_name2 + " is schedule to start"
                    print(s)

                else:
                    cursor.execute("UPDATE classrooms SET current_course_time_left=? WHERE id=?",
                                   [0, class_id])
                    cursor.execute("UPDATE classrooms SET current_course_id =? WHERE id=?",
                                   [0, class_id])
                    dbcon.commit()

            else:
                cursor.execute("SELECT * FROM courses WHERE id =(?)", [current_course_id])
                temp = cursor.fetchone()
                course_name = temp[1]
                s = '(' + str(iterationcounter) + ') ' + location + ": " + "occupied by " + course_name
                print(s)
                time_left = time_left - 1
                cursor.execute("UPDATE classrooms SET current_course_time_left=? WHERE id=?",
                               [time_left, class_id])
                dbcon.commit()

        printtables()

        iterationcounter += 1
        cursor.execute("SELECT * FROM courses")
        list7 = cursor.fetchall()
        number_of_courses = 0
        for item in list7:
            number_of_courses += 1


if __name__ == '__main__':
    main()

